package com.example.teste_mongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
